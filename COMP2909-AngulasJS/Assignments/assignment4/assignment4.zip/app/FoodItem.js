"use strict";
var FoodItem = (function () {
    function FoodItem() {
    }
    return FoodItem;
}());
exports.FoodItem = FoodItem;
//# sourceMappingURL=FoodItem.js.map