export class FoodItem {
    
    id: number;
    name: string;
    mfg: string;
    pkg: string;
    qty: number;
}