"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var service_food_1 = require('./service.food');
var HomeComponent = (function () {
    function HomeComponent(foodService) {
        this._foodService = foodService;
        this.getFoods();
    }
    HomeComponent.prototype.getFoods = function () {
        var _this = this;
        this._foodService.getFoods().then(function (foods) { return _this.foods = foods; });
    };
    HomeComponent = __decorate([
        core_1.Component({
            templateUrl: './home.html',
            styles: ['table { width: 40%; margin: 2% 0 0 -4%; }'],
            providers: [service_food_1.FoodService]
        }), 
        __metadata('design:paramtypes', [service_food_1.FoodService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=app.home.js.map