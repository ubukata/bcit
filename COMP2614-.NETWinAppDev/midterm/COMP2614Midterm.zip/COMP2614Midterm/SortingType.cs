﻿
namespace COMP2614Midterm
{
    public enum SortingType
    {
        NaturalOrder,
        SortedByExpirationDate
    }
}
