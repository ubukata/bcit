$(function(){
	$(".cornered").corner("bevelfold");
});